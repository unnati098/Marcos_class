module.exports = app => {
    const product = require('../controllers/product.controller.js')
    const router = require('express').Router() 

    router.get('/', product.findAll)

    router.post('/', product.create)

    router.put('/:id', product.update)

    router.get('/:id', product.findOne)

    router.delete('/:id', product.delete)

    app.use('/api/product', router)
}